require(["jquery", "underscore", "backbone", "app/router", "mixpanelSnippet", "modernizr", "app/app"], function($, _, Backbone, Router, mixpanelSnippet, modernizr, App) {
  var app = new App();
  app.render();
  $("body").append(app.el);
  window.csxportal = app;
  var router = new Router({app: app});
  window.csxrouter = router;
  if(!(Backbone.History.started)) Backbone.history.start();
});